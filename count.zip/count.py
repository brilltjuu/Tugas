import sys
str1 = "23"
alphabets = digits = special = 0

for line in sys.stdin:
    str1 = line
    for x in range(len(str1)):
        if((str1[x] >= 'a' and str1[x] <= 'z') or (str1[x] >= 'A' and str1[x] <= 'Z')): 
            alphabets = alphabets + 1 
        elif(str1[x] >= '0' and str1[x] <= '9'):
            digits = digits + 1
        else:
            special = special + 1

sys.stdout.write("Total angka: " + str(digits))
sys.stdout.write('\n')
sys.stdout.write("Total huruf: " + str(alphabets))
sys.stdout.write('\n')
sys.stdout.write("Total symbol: " + str(special))
sys.stdout.write('\n')
